import json
from quiz_master.app import create_app
from quiz_master.models import db, Question


def setup_module(module):
    app = create_app()
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    with app.app_context():
        db.create_all()
        q = Question(category='Test', question='1+1?', choices=json.dumps(['1','2','3']), correct_index=1)
        db.session.add(q)
        db.session.commit()
    module.app = app


def test_submit():
    client = module.app.test_client()
    # prepare answer with correct choice index 1
    resp = client.post('/submit', json={'answers': {str(Question.query.first().id): 1}})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data['score'] == 1
    assert data['total'] == 1
