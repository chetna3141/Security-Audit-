// (reserved) client JS can live here for future enhancements
console.log('Quiz Master static loaded');
